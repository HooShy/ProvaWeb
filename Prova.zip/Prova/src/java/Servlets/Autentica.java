/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servlets;

import Dao.Dao;
import Dao.User;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author aluno
 */
public class Autentica implements Command {

    private static Dao theDao = new Dao();

    @Override
    public void execute(HttpServletRequest request, HttpServletResponse response) {
        try {

            if (request.getParameter("acao").equals("login")) {
                List<User> list = theDao.getTodosUsuarios();
                for (User u : list) {
                    if (u.getNome().equals(request.getParameter("user"))) {
                        if (u.getSenha().equals(request.getParameter("pass"))) { 
                            if(u.getNivelAcess() == 10){
                                response.sendRedirect("controler?comando=MenuAdm");
                            }else{
                                response.sendRedirect("controler?comando=MenuUser");
                            }
                            
                        }
                    } else {
                        RequestDispatcher d = request.getRequestDispatcher("Prova2/Index.jsp?erro=1");
                        d.forward(request, response);
                    }
                }

            } else {
                response.sendRedirect("/Prova/controler?comando=NotFound");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
