/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servlets;

import Dao.Dao;
import Dao.User;
import FestaDao.DaoFest;
import FestaDao.Festa;
import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author aluno
 */
public class Festas implements Command {
    
    private static DaoFest theDao = new DaoFest();

    @Override
    public void execute(HttpServletRequest request, HttpServletResponse response) {
        
        try {
            Festa festa = new Festa(request.getParameter("data"), request.getParameter("hora"), request.getParameter("titulo"), false);
            theDao.add(festa);
            response.sendRedirect("controler?comando=MenuAdm");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
