/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author Kainan
 */
public class Dao implements UsuarioDao{
    Scanner scan = new Scanner(System.in);
    ArrayList<User> usuarios = new ArrayList<User>();
    
    public Dao(){      
      
        User user1 = new User(121029, "kainan", "kainan@kmail.com", "1234", 10);
        usuarios.add(user1);

    }
    

    @Override
    public List<User> getTodosUsuarios() {
        return usuarios;
    }

    @Override
    public User getUsuarios(String nome) {
        for(User usuario : usuarios){
            if(usuario.getNome().equals(nome)){
                return usuario;
            }
        }
        return null;
    }

    @Override
    public void updateUsuarios(User usuario) {
        for(User u : usuarios){
           if(usuario.equals(usuario)){
                System.out.println("Novo nome\n");
                usuario.setNome(scan.next());
                System.out.println("Nova senha\n");
                usuario.setSenha(scan.next());
                
            }else{
               usuarios.add(u);
           } 
        }
    }

    @Override
    public void deleteUsuarios(User usuario) {
        for(User u : usuarios){
           if(usuario.equals(usuario)){
                usuario.setNome(null);
                usuario.setSenha(null);
            } 
        }
    }

    @Override
    public void add(User usuario) {
        usuarios.add(usuario);
    }

    
    
}
