/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FestaDao;

import Dao.User;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author aluno
 */
public class DaoFest implements FestaDao{
    List<Festa> festas = new ArrayList<Festa>();
    List<User> usuarios = new ArrayList<User>();
    public DaoFest(){
        Festa f1 = new Festa("20/06/2018", "19:00", "São joão do campus", true);
        festas.add(f1);
        Festa f2 = new Festa("21/07/2018", "21:00", "copa", false);
        festas.add(f2);
    }
    
    @Override
    public List<Festa> getTodasFestas() {
        return festas;
    }

    @Override
    public User getFestas(String nome) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void updateFesta(Festa festa) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void deleteFesta(Festa festa) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void add(Festa festa) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
