/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FestaDao;

import java.util.List;

/**
 *
 * @author aluno
 */
public class Festa {
    private String data;
    private String hora;
    private String título;
    private boolean vou;
    
    

    public Festa(String data, String hora, String título, boolean vou) {
        this.data = data;
        this.hora = hora;
        this.título = título;
        this.vou = vou;
     
       
    }

    

    public boolean isVou() {
        return vou;
    }

    public void setVou(boolean vou) {
        this.vou = vou;
    }
    

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }

    public String getTítulo() {
        return título;
    }

    public void setTítulo(String título) {
        this.título = título;
    }

    
     
}
